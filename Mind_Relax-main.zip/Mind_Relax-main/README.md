# Mind Relax
## A simple Ui for Mind Calmness App
<img src="/images/Screenshot_20210226-122140[1].jpg" width="250"> 
<img src="/images/Screenshot_20210226-122146[1].jpg" width="250">
<img src ="/images/Screenshot_20210226-122151[1].jpg" width="250">
